<?php
try
{
	
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
