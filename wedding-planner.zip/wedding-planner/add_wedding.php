<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bride_name = $_POST['bride_name'];
    $groom_name = $_POST['groom_name'];
    $wedding_date = $_POST['wedding_date'];
    $venue = $_POST['venue'];
    $guest_count = $_POST['guest_count'];
    $budget = $_POST['budget'];
    $description = $_POST['description'];
    
    $stmt = $pdo->prepare("INSERT INTO weddings (user_id, bride_name, groom_name, wedding_date, venue, guest_count, budget, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $bride_name, $groom_name, $wedding_date, $venue, $guest_count, $budget, $description]);
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Wedding - Wedding Planner</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Wedding</h1>
        <form method="POST">
            <div class="form-group">
                <label>Bride's Name:</label>
                <input type="text" name="bride_name" required>
            </div>
            <div class="form-group">
                <label>Groom's Name:</label>
                <input type="text" name="groom_name" required>
            </div>
            <div class="form-group">
                <label>Wedding Date:</label>
                <input type="date" name="wedding_date" required>
            </div>
            <div class="form-group">
                <label>Venue:</label>
                <input type="text" name="venue" required>
            </div>
            <div class="form-group">
                <label>Guest Count:</label>
                <input type="number" name="guest_count" required>
            </div>
            <div class="form-group">
                <label>Budget ($):</label>
                <input type="number" step="0.01" name="budget" required>
            </div>
            <div class="form-group">
                <label>Description:</label>
                <textarea name="description" rows="4"></textarea>
            </div>
            <button type="submit">Add Wedding</button>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>