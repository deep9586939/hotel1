<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

 $stmt = $pdo->prepare("SELECT * FROM weddings WHERE user_id = ?");
 $stmt->execute([$_SESSION['user_id']]);
 $weddings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Wedding Planner</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="nav">
            <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
            <a href="logout.php">Logout</a>
        </div>
        <h2>Your Weddings</h2>
        <a href="add_wedding.php">Add New Wedding</a>
        
        <?php if (empty($weddings)): ?>
            <p>No weddings planned yet. Add your first wedding!</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Bride</th>
                    <th>Groom</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($weddings as $wedding): ?>
                <tr>
                    <td><?php echo $wedding['bride_name']; ?></td>
                    <td><?php echo $wedding['groom_name']; ?></td>
                    <td><?php echo $wedding['wedding_date']; ?></td>
                    <td><?php echo $wedding['venue']; ?></td>
                    <td>
                        <a href="view_wedding.php?id=<?php echo $wedding['id']; ?>">View</a>
                        <a href="edit_wedding.php?id=<?php echo $wedding['id']; ?>">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>