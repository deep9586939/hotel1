<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Wedding Planner</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Wedding Planner</h1>
        <div class="nav">
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </div>
        <p>Plan your perfect wedding with our easy-to-use planner. Register or login to get started!</p>
    </div>
</body>
</html>