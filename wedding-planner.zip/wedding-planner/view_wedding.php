<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

 $id = $_GET['id'];
 $stmt = $pdo->prepare("SELECT * FROM weddings WHERE id = ? AND user_id = ?");
 $stmt->execute([$id, $_SESSION['user_id']]);
 $wedding = $stmt->fetch();

if (!$wedding) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Wedding - Wedding Planner</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Wedding Details</h1>
        <p><strong>Bride's Name:</strong> <?php echo $wedding['bride_name']; ?></p>
        <p><strong>Groom's Name:</strong> <?php echo $wedding['groom_name']; ?></p>
        <p><strong>Wedding Date:</strong> <?php echo $wedding['wedding_date']; ?></p>
        <p><strong>Venue:</strong> <?php echo $wedding['venue']; ?></p>
        <p><strong>Guest Count:</strong> <?php echo $wedding['guest_count']; ?></p>
        <p><strong>Budget:</strong> $<?php echo number_format($wedding['budget'], 2); ?></p>
        <p><strong>Description:</strong></p>
        <p><?php echo nl2br($wedding['description']); ?></p>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>